public enum Color
{
    AMARILLO, AZUL, ROJO, VERDE
}
